package tp5;

import java.util.Map;

public class HashCouple implements Map.Entry<String, Integer>{

	protected String key ;
	protected int value;
	
	
	
	public HashCouple() {
		this.key = null;
		this.value = 0;
	}
	
	public HashCouple(String key, int value) {
		super();
		this.key = key;
		this.value = value;
	}
	@Override
	public String getKey() {
		return this.key;
	}
	@Override
	public Integer getValue() {
		return this.value;
	}
	@Override
	public Integer setValue(Integer value) {
		this.value = value;
		
		return this.value;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		result = prime * result + value;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HashCouple other = (HashCouple) obj;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		if (value != other.value)
			return false;
		return true;
	}
}
	