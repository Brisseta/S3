package tp5;

public class Chainage implements HashTable{

	private MaListe[] tableau;
	
	
	@Override
	public int put(String key, int value) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int get(String key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean remove(String key) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

}
