package tp5;


public class MaListe {

	MaListe next;
	HashCouple hash;

	public MaListe(HashCouple c){

		this.hash = c;
	}

	public void add(HashCouple c){

		this.next = new MaListe(c);
	}

	public HashCouple remove(String key) {
		MaListe tmp = this;

		while(tmp.next != null) {

			if (tmp.next.hash.key == key) {

				HashCouple retour = tmp.next.hash;
				tmp.next = tmp.next.next;
				return retour;
			}
			tmp = tmp.next;
		}
		return null;
	}
	public void affichage() {
		
		MaListe tmp = this;
		String retour = "[";
		retour = retour+"("+tmp.hash.key+","+tmp.hash.value+")";
		while(tmp.next != null) {
			retour = retour+"("+tmp.next.hash.key+","+tmp.next.hash.value+")";
			tmp = tmp.next;
		}
		retour = retour+"]";
		System.out.println(retour);

	}
	public static void main(String[] args) {
		MaListe tmp = new MaListe(new HashCouple());
		tmp.add(new HashCouple("toto", 0));
		tmp.add(new HashCouple("toto", 3));
		tmp.affichage();
		
	}
}
