package tp5;

public interface HashTable{
	
	public int put(String key ,int value);
	
	public int get(String key);
	
	public boolean remove(String key);
	
	public int size();
}