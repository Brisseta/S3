package try_to_BDD_in_Java;

import java.awt.ScrollPaneAdjustable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Exo4 {

	public static void main(String[] args) {
		 try {
			 Class.forName("org.postgresql.Driver");
		      System.out.println("Driver O.K.");

		      String url = "jdbc:postgresql://localhost:5432/Essai";
		      String user = "postgres";
		      String passwd = "root";
		      
		      Connection connection = DriverManager.getConnection(url, user, passwd);
		      System.out.println("Connexion effective !");
		      
		      
		      String query="SELECT prof_nom,prof_prenom FROM professeur ";
		      query += "WHERE prof_nom = ? ";
		      query += "OR prof_id = ? ";
		      
		      PreparedStatement prepare =connection.prepareStatement(query);
		      prepare.setString(1,"MANOU");
		      prepare.setInt(2, 2);
		      System.out.println(prepare.toString());
		      
		      prepare.setString(1, "TOTO");
		      prepare.setInt(2, 154);
		      System.out.println(prepare.toString());
		      
		      prepare.setString(1, "TITI");
		      prepare.setInt(2, 25456116);
		      System.out.println(prepare.toString());
		      
		      prepare.close();
		      connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
