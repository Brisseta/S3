package try_to_BDD_in_Java;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Exo6 {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver O.K.");

			String url = "jdbc:postgresql://localhost:5432/Essai";
			String user = "postgres";
			String passwd = "root";

			Connection connection = DriverManager.getConnection(url, user, passwd);
			System.out.println("Connexion effective !");
			Statement state = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE , ResultSet.CONCUR_UPDATABLE);

			String query="SELECT prof_id, prof_nom , prof_prenom FROM professeur WHERE prof_nom='MAMOU'";

			ResultSet result = state.executeQuery(query);
			result.first();
			System.out.println("NOM : "+ result.getString("prof_nom")+" PRENOM : "+ result.getString("prof_prenom"));
			
			result.updateString("prof_nom", "COURTEL");
			result.updateString("prof_prenom", "Angelo");
			result.updateRow();
			
			System.out.println(" \n \t _______________ \n MODIFICATION \n \t ____________________");
			System.out.println("NOM : "+ result.getString("prof_nom")+" PRENOM : "+ result.getString("prof_prenom"));
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
