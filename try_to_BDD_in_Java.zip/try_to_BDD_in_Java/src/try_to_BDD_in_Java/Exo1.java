package try_to_BDD_in_Java;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class Exo1 {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver OK !");

			String url = "jdbc:postgresql://localhost:5432/Essai";
			String user = "postgres";
			String passwd = "root";
			
			Connection conn = DriverManager.getConnection(url, user, passwd);
			java.sql.Statement state = conn.createStatement();
			ResultSet result = state.executeQuery("SELECT * FROM professeur");
			ResultSetMetaData resultMeta = result.getMetaData();
			
			//nbre de colonnes
			System.out.println("Il y a : "+resultMeta.getColumnCount()+" Colonnes dans cette table .");
			
			for (int i = 1; i < resultMeta.getColumnCount(); i++) {
				System.out.println("\t"+resultMeta.getColumnTypeName(i));
			}
			
			System.out.println("Voici les nom et prenoms");
			System.out.println("________________________");
			
			while (result.next()) {
				System.out.print("t"+result.getString("prof_nom")+" |");
				System.out.print("\t"+result.getString("prof_prenom")+" | \n");
			}
			result.close();
			state.close();
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

}
