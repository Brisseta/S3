package try_to_BDD_in_Java;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Exo5 {
	long toto = 10_54_54;

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver O.K.");

			String url = "jdbc:postgresql://localhost:5432/Essai";
			String user = "postgres";
			String passwd = "root";

			Connection connection = DriverManager.getConnection(url, user, passwd);
			System.out.println("Connexion effective !");
			Statement state = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE , ResultSet.CONCUR_UPDATABLE);

			String query="SELECT prof_nom , prof_prenom FROM professeur";

			ResultSet result = state.executeQuery(query);

			System.out.println("\n\t"
					+ "_______________________________"
					+ "\n\t\t LECTURE STANDARD . \n\t"
					+ "_______________________________\n");
			int i = 1;

			while (result.next()) {
				System.out.println("\t NOM = "+result.getString("prof_nom")+" \t PRENOM = "+result.getString("prof_prenom"));
				if(result.isLast())
					System.out.println("\t\t DERNIER RESULTAT");

				i++;
			}
			if(result.isAfterLast())
				System.out.println("\t\t TERMINE");

			System.out.println("\n\t"
					+ "_______________________________"
					+ "\n\t\t LECTURE SENS CONTRAIRE . \n\t"
					+ "_______________________________\n");

			while (result.previous()) {
				System.out.println("\t NOM = "+result.getString("prof_nom")+" \t PRENOM = "+result.getString("prof_prenom"));
				if(result.isFirst())
					System.out.println("\t\t DEBUT ");
			}
			if(result.isBeforeFirst())
				System.out.println(" \t On est Avant le debut");

			System.out.println("\n\t"
					+ "_______________________________"
					+ "\n\t\t APRES POSITIONEMENT ABSOLU A "+i/2
					+ " . \n\t"
					+ "_______________________________\n");
			
			result.absolute(i/2);
			
			while(result.next()){
				System.out.println("\t NOM = "+result.getString("prof_nom")+" \t PRENOM = "+result.getString("prof_prenom"));
				
			}
			System.out.println("\n\t"
					+ "_______________________________"
					+ "\n\t\t APRES POSITIONEMENT RELATIF A "+(i-(i-2))
					+ " . \n\t"
					+ "_______________________________\n");
			result.relative(-(i-2));
			
			while(result.next())
				System.out.println("\t NOM = "+result.getString("prof_nom")+" \t PRENOM = "+result.getString("prof_prenom"));
			result.close();
			state.close();

		}catch (Exception e) {

			e.printStackTrace();
		}
	}
}
