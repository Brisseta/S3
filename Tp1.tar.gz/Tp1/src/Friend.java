
public class Friend implements Comparable<Friend> {
	private String name ;
	private int age;
	
	
	
	@Override
	public int compareTo(Friend f) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
