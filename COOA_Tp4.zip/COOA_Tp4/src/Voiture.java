
public class Voiture {
	private Etat etat_voiture;
	private String modele;
	private Atelier reparation;

	public Voiture(String modele, Etat etat) {
		this.etat_voiture = etat;
		this.modele = modele;
		if (this.etat_voiture == Etat.PAGNE_SEVERE)
			this.reparation = new AtelierSevere();
		else if (this.etat_voiture == Etat.PAGNE_SEVERE)
			this.reparation = new AtelierLeger();
	}

	@Override
	public String toString() {
		return "Voiture [etat_voiture=" + etat_voiture + " modele=" + modele + "]";
	}

	public Etat getEtat_voiture() {
		return etat_voiture;
	}

	public void setEtat_voiture(Etat etat_voiture) {
		this.etat_voiture = etat_voiture;
	}

	public String getModele() {
		return modele;
	}

	public void setModele(String modele) {
		this.modele = modele;
	}

	public Atelier getReparation() {
		return reparation;
	}

	public void setReparation(Atelier reparation) {
		this.reparation = reparation;
	}

}
