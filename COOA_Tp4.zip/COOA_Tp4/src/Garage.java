
import java.util.Iterator;

public class Garage implements Iterable<Voiture> {

	private Voiture[] liste;
	private IteratorVoiture it;
	private AtelierLeger atelierLeger;
	private AtelierSevere atelierSevere;
	

	public Garage(int taille) {
		liste = new Voiture[taille];
		it = new IteratorVoiture(this);
	}

	@Override
	public Iterator<Voiture> iterator() {
		return it;
	}

	public static void main(String[] args) {
		Garage BMW = new Garage(2);
		BMW.getListe()[0] = new Voiture("serie 5", Etat.MARCHE);
		BMW.getListe()[1] = new Voiture("kebab", Etat.PAGNE_SEVERE);
		Iterator<Voiture> tmp = BMW.iterator();
		while (tmp.hasNext()) {
			Voiture voiture = (Voiture) tmp.next();
			System.out.println(voiture);

		}
	}

	public Voiture[] getListe() {
		return liste;
	}

	public void setListe(Voiture[] liste) {
		this.liste = liste;
	}

	public void add(Voiture ajout) {
		liste[it.getIndex()] = ajout;
		it.setIndex(it.getIndex() + 1);
	}

}
