import java.util.Random;
import java.util.Timer;

public abstract class Atelier {
	boolean etat;
	Timer time;
	Random rd ;
	abstract void reparerVoiture(Voiture voiture);
}
