import java.util.Iterator;

public class IteratorVoiture implements Iterator<Voiture> {

	int index;
	Garage garage;
	public IteratorVoiture(Garage tmp) {
		this.garage = tmp;
		this.index = 0;
	}
	@Override
	public boolean hasNext() {
		if(index < this.garage.getListe().length){
			return true;
		}
		return false;
	}

	@Override
	public Voiture next() {
		if(this.hasNext()){
			return 
		}
		index++;
		return null;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
}
