import java.util.Random;
import java.util.Timer;


 class AtelierSevere extends Atelier{

	@Override
	void reparerVoiture(Voiture voiture) {
		if(voiture.getEtat_voiture() == Etat.PAGNE_SEVERE){
			this.time = new Timer();
			this.rd = new Random();
			time.schedule(null, (rd.nextInt(3)+3)*1000);
			this.etat = false;
			time.cancel();
			this.etat = true;
			voiture.setEtat_voiture(Etat.MARCHE);
		}
	}
}
