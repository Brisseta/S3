#include <stdio.h>

int fonction_a(int param);
//todo
