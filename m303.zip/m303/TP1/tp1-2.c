#include <stdio.h>

int fonction_a(int param)
{
	 return 42 + param;
}
//todo