#include <stdio.h>
#include "tp1-2.h"

void fonction_b(int param);