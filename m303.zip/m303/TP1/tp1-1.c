#include <stdio.h>
#include "tp1-2.h"
#include "tp1-3.h"



int main(void)
{
	fonction_a(0);
	fonction_b(20);
	return 0;
}
//todo