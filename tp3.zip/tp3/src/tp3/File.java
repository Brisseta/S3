package tp3;

import java.util.Stack;

public class File<E>{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5217270904450675105L;
	
	private int indextete;
	
	private int indexqueue;
	
	private  Cellule[]contenu;
	
	private int tailleamax;
	
	public File() {
		contenu = (Cellule[]) new Object[tailleamax];
	}


	public int getIndextete() {
		return indextete;
	}

	public int getIndexqueue() {
		return indexqueue;
	}

	public Cellule[] getContenu() {
		return contenu;
	}
	

}
