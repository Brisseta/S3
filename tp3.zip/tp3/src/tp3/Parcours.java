package tp3;

import java.util.Stack;

public class Parcours {
	public static void main(String[] args) {
		Labyrinthe l = new Labyrinthe();
		Stack<Cellule> p = new Stack<>();
		boolean find=false;
		l.poserMarque(1,1);
		p.push(new Cellule(1,1));
		while (!p.isEmpty() && !find) {
			
			try {
				Thread.sleep(100);
			} catch (Exception e) {
				// TODO: handle exception
			}
			System.out.println("Pile : " + p);
			Cellule c = p.lastElement();
			l.poserMarqueRetour(c.getX(),c.getY());
			if(c.equals(new Cellule(l.n()-1,l.n()-2))){
				find = true;
			}else{
				boolean flag= false;
				if(c.getX() != l.n()-1 && !(l.estMur(c.getX()+1, c.getY()) || l.estMarque(c.getX()+1, c.getY()))){
					l.poserMarque(c.getX()+1, c.getY());
					p.push(new Cellule(c.getX()+1,c.getY()));
					flag=true;
				}
				else if(c.getY() != l.n()-1 &&!(l.estMur(c.getX(), c.getY()+1) || l.estMarque(c.getX(), c.getY()+1))){
					l.poserMarque(c.getX(),c.getY()+1);
					p.push(new Cellule(c.getX(),c.getY()+1));
					flag=true;
				}
				else if(c.getX() != 0 &&!(l.estMur(c.getX()-1, c.getY()) || l.estMarque(c.getX()-1, c.getY()))){
					l.poserMarque(c.getX()-1,c.getY());
					p.push(new Cellule(c.getX()-1,c.getY()));
					flag=true;
				}
				else if(c.getY() != 0 && !(l.estMur(c.getX(), c.getY()-1) || l.estMarque(c.getX(), c.getY()-1))){
					l.poserMarque(c.getX(),c.getY()-1);
					p.push(new Cellule(c.getX(),c.getY()-1));
					flag=true;
				}else if(!flag){
					p.pop();
				}
			}
		}
		if(find){
			System.out.println(" SORTIE TROUVEE");
			for(Cellule ch : p)
				l.poserMarque(ch.getX(), ch.getY());
		}
		else
			System.err.println("PAS DE CHEMIN TROUVE");
			
	}
}
